package dao;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import datos.Usuario;

public class UsuariosDao {
//_______________________________________________________________________________________________________________________________
	private Usuario clasePersistente;
	protected static Session session;
    protected Transaction tx;
 //_______________________________________________________________________________________________________________________________
public Usuario getClasePersistente() {return clasePersistente;} 
protected void UsuarioDao(){  
 this.clasePersistente = (Usuario)((ParameterizedType)getClass().getGenericSuperclass()).getActualTypeArguments()[0];
} 
protected void iniciaOperacion() throws HibernateException {
     session = HibernateUtil.getSessionFactory().openSession();
     tx = session.beginTransaction();
 }
protected void manejaExcepcion(HibernateException he) throws HibernateException {
     tx.rollback();
     throw new HibernateException("ERROR en la capa de acceso a datos", he);
 }
 //_______________________________________________________________________________________________________________________________
@SuppressWarnings("unchecked")	
public List<Usuario> traerUsurios() throws HibernateException {List<Usuario> lista=null;
try {iniciaOperacion();lista=session.createQuery("from "+clasePersistente).list();  
}finally {session.close();}return lista;
}
//_______________________________________________________________________________________________________________________________
public Usuario traer(int id) {
Usuario objeto = null;
try {iniciaOperacion();objeto = (Usuario) session.createQuery("from Usuario u where u.idCliente =" + id).uniqueResult();}
finally{session.close();}return objeto;
}
//_______________________________________________________________________________________________________________________________
public int agregar(Usuario objeto) {
int id = 0;
try {iniciaOperacion();id = (int)session.save(objeto);tx.commit();} 
catch (HibernateException he) {manejaExcepcion(he);throw he;} 
finally {session.close();}return id;
}
//_______________________________________________________________________________________________________________________________
public void actualizar(Usuario objeto) throws HibernateException {
try {iniciaOperacion();session.update(objeto);tx.commit();
}catch (HibernateException he) {manejaExcepcion(he);throw he;} finally {session.close();}}
//_______________________________________________________________________________________________________________________________
public void eliminar(Usuario objeto) throws HibernateException {
try {iniciaOperacion();session.delete(objeto);tx.commit();} 
catch (HibernateException he) {manejaExcepcion(he);throw he;} 
finally{session.close();}
}
//_______________________________________________________________________________________________________________________________

}
