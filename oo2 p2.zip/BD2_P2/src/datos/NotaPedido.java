package datos;

public class NotaPedido {
//._._._._._._._._._._._._._._._._._._._._
	private int id;
	private char turno;
	private Aula aula;
	private int cantestudiantes;
	private Catedra catedra;
	private String descripcion;
//._._._._._._._._._._._._._._._._._._._._
public NotaPedido(){}
public NotaPedido(int id, char turno, Aula aula, int cantestudiantes, Catedra catedra, String descripcion) {
	super();
	this.id = id;
	this.turno = turno;
	this.aula = aula;
	this.cantestudiantes = cantestudiantes;
	this.catedra = catedra;
	this.descripcion = descripcion;
}
//._._._._._._._._._._._._._._._._._._._._
public int getId() {
	return id;
}
protected void setId(int id) {
	this.id = id;
}
public char getTurno() {
	return turno;
}
public void setTurno(char turno) {
	this.turno = turno;
}
public Aula getAula() {
	return aula;
}
public void setAula(Aula aula) {
	this.aula = aula;
}
public int getCantestudiantes() {
	return cantestudiantes;
}
public void setCantestudiantes(int cantestudiantes) {
	this.cantestudiantes = cantestudiantes;
}
public Catedra getCatedra() {
	return catedra;
}
public void setCatedra(Catedra catedra) {
	this.catedra = catedra;
}
public String getDescripcion() {
	return descripcion;
}
public void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
}
//._._._._._._._._._._._._._._._._._._._._
@Override
public String toString() {
	return "NotaPedido [id=" + id + ", turno=" + turno + ", aula=" + aula.toString() + ", cantestudiantes=" + cantestudiantes
			+ ", catedra=" + catedra.toString() + ", descripcion=" + descripcion + "]";
	//._._._._._._._._._._._._._._._._._._._._
}

}
