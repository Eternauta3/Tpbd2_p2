package datos;

import java.util.Set;

public class Materia {
//-------------------------------------
	private int id;
	private String materia;
	private Catedra catedra;
	private Set<Usuario> profesores;
	private Set<Usuario> alumnos;
//-------------------------------------
public Materia() {}
public Materia(String materia, Catedra catedra, Set<Usuario> profesores, Set<Usuario> alumnos) {
	super();
	this.materia = materia;
	this.catedra = catedra;
	this.profesores = profesores;
	this.alumnos = alumnos;
}
//-------------------------------------
public int getId() {
	return id;
}
protected void setIda(int id) {
	this.id = id;
}
public String getMateria() {
	return materia;
}
public void setMateria(String materia) {
	this.materia = materia;
}
public Catedra getCatedra() {
	return catedra;
}
public void setCatedra(Catedra catedra) {
	this.catedra = catedra;
}
public Set<Usuario> getProfesores() {
	return profesores;
}
public void setProfesores(Set<Usuario> profesores) {
	this.profesores = profesores;
}
public Set<Usuario> getAlumnos() {
	return alumnos;
}
public void setAlumnos(Set<Usuario> alumnos) {
	this.alumnos = alumnos;
}
//-------------------------------------
@Override
public String toString() {
	return "Materia [idmateria=" + id + ", materia=" + materia + ", catedra=" + catedra + ", profesores="
			+ profesores.toString() + ", alumnos=" + alumnos.toString() + "]";
}
//-------------------------------------
}
