package datos;

public class Usuario {
//___________________________________________________________
	private String nombre;
	private String apellido;
	private long dni_usuario;
	private String tipo_dni;
	private String email_usuario;
	private String usuario_nombre;
	private String usuario_contrase�a;
	private String perfil_usuario;
	private Boolean baja;
//____________________________________________________________
public Usuario(){}
public Usuario
(String nombre, String apellido, long dni_usuario,String tipo_dni, String email_usuario, String usuario_contrase�a, String perfil_usuario) {
	super();
	this.nombre = nombre;
	this.apellido = apellido;
	this.dni_usuario = dni_usuario;
	this.tipo_dni = tipo_dni;
	this.email_usuario = email_usuario;
	this.usuario_nombre = email_usuario;
	this.usuario_contrase�a = usuario_contrase�a;
	this.perfil_usuario = perfil_usuario;
	this.baja = false;
}
//____________________________________________________________
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public String getApellido() {
	return apellido;
}
public void setApellido(String apellido) {
	this.apellido = apellido;
}
public long getDni_usuario() {
	return dni_usuario;
}
public void setDni_usuario(long dni_usuario) {
	this.dni_usuario = dni_usuario;
}
public String getTipo_dni() {
	return tipo_dni;
}
public void setTipo_dni(String tipo_dni) {
	this.tipo_dni = tipo_dni;
}
public String getEmail_usuario() {
	return email_usuario;
}
public void setEmail_usuario(String email_usuario) {
	this.email_usuario = email_usuario;
}
public String getUsuario_nombre() {
	return usuario_nombre;
}
public void setUsuario_nombre(String usuario_nombre) {
	this.usuario_nombre = usuario_nombre;
}
public String getUsuario_contrase�a() {
	return usuario_contrase�a;
}
public void setUsuario_contrase�a(String usuario_contrase�a) {
	this.usuario_contrase�a = usuario_contrase�a;
}
public String getPerfil_usuario() {
	return perfil_usuario;
}
public void setPerfil_usuario(String perfil_usuario) {
	this.perfil_usuario = perfil_usuario;
}
public Boolean getBaja() {
	return baja;
}
public void setBaja(Boolean baja) {
	this.baja = baja;
}
//____________________________________________________________
@Override
public String toString() {
	return "Usuario [nombre=" + nombre + ", apellido=" + apellido + ", dni_usuario=" + dni_usuario + ", tipo_dni="
			+ tipo_dni + ", email_usuario=" + email_usuario + ", usuario_nombre=" + usuario_nombre
			+ ", usuario_contrase�a=" + usuario_contrase�a + ", perfil_usuario=" + perfil_usuario + ", baja=" + baja
			+ "]";
}
//____________________________________________________________
}
