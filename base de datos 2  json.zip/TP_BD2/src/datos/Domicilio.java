package datos;

public class Domicilio {
//___
	private String calle;
	private String localidad;
	private long numero;
	private String provincia;
//___
public Domicilio() {}
public Domicilio(String calle, String localidad, long numero, String provincia) {
	this.calle = calle;
	this.localidad = localidad;
	this.numero = numero;
	this.provincia = provincia;
}
//____
public String getCalle() {
	return calle;
}
public void setCalle(String calle) {
	this.calle = calle;
}
public String getLocalidad() {
	return localidad;
}
public void setLocalidad(String localidad) {
	this.localidad = localidad;
}
public long getNumero() {
	return numero;
}
public void setNumero(long numero) {
	this.numero = numero;
}
public String getProvincia() {
	return provincia;
}
public void setProvincia(String provincia) {
	this.provincia = provincia;
}
//_____________________________________________________________________
@Override
public String toString() {
	return "Domicilio [calle=" + calle + ", localidad=" + localidad + ", numero=" + numero + ", provincia=" + provincia
			+ "]";
}
//______________________________________________________________
}
