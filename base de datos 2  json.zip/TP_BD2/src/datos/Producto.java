package datos;

public class Producto {
	private String tipo_producto;
	private String descripcion;
	private String nombre_de_producto;
	private int id_producto;
	private float precio_unitario;
//___
public Producto(){}

public Producto(String tipo_producto, String descripcion, String nombre_de_producto, float precio_unitario,
		int id_producto) {
	super();
	this.tipo_producto = tipo_producto;
	this.descripcion = descripcion;
	this.nombre_de_producto = nombre_de_producto;
	this.precio_unitario = precio_unitario;
	this.id_producto = id_producto;
}

//___
public String getTipo_producto() {
	return tipo_producto;
}
public void setTipo_producto(String tipo_producto) {
	this.tipo_producto = tipo_producto;
}
public String getDescripcion() {
	return descripcion;
}
public void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
}
public String getNombre_de_producto() {
	return nombre_de_producto;
}
public void setNombre_de_producto(String nombre_de_producto) {
	this.nombre_de_producto = nombre_de_producto;
}
public int getId_producto() {
	return id_producto;
}
public void setId_producto(int id_producto) {
	this.id_producto = id_producto;
}
public float getPrecio_unitario() {
	return precio_unitario;
}
public void setPrecio_unitario(float precio_unitario) {
	this.precio_unitario = precio_unitario;
}
//______________________________________________________________
@Override
public String toString() {
	return "Producto [tipo_producto=" + tipo_producto + ", descripcion=" + descripcion + ", nombre_de_producto="
			+ nombre_de_producto + ", id_producto=" + id_producto + ", precio_unitario=" + precio_unitario + "]";
}
//____________
}
