package datos;

//import antlr.collections.List;

public class Sucursal {
//___
	private int id_Sucursal;
	private String calle_domicilio;
	private String nombre_empleado;
	private String nombre_cajero;
	private long cod_ticket;
	
//___
public Sucursal(){}

public Sucursal(String calle_domicilio, String nombre_empleado, String nombre_cajero, int id_Sucursal,Long cod_ticket) {
	super();
	this.calle_domicilio = calle_domicilio;
	this.nombre_empleado = nombre_empleado;
	this.nombre_cajero = nombre_cajero;
	this.id_Sucursal = id_Sucursal;
	this.cod_ticket=cod_ticket;
}

//________

public String getCalle_domicilio() {
	return calle_domicilio;
}
public long getCod_ticket() {
	return cod_ticket;
}

public void setCod_ticket(long cod_ticket) {
	this.cod_ticket = cod_ticket;
}

public void setCalle_domicilio(String calle_domicilio) {
	this.calle_domicilio = calle_domicilio;
}
public String getNombre_empleado() {
	return nombre_empleado;
}
public void setNombre_empleado(String nombre_empleado) {
	this.nombre_empleado = nombre_empleado;
}
public String getNombre_cajero() {
	return nombre_cajero;
}
public void setNombre_cajero(String nombre_cajero) {
	this.nombre_cajero = nombre_cajero;
}

public int getId_Sucursal() {
	return id_Sucursal;
}

public void setId_Sucursal(int id_Sucursal) {
	this.id_Sucursal = id_Sucursal;
}
//_______________________________________________________________________

@Override
public String toString() {
	return "Sucursal [id_Sucursal=" + id_Sucursal + ", calle_domicilio=" + calle_domicilio + ", nombre_empleado="
			+ nombre_empleado + ", nombre_cajero=" + nombre_cajero + ", cod_ticket=" + cod_ticket + "]";
}


//_______________________________________________________________________

//_____________________________________________________________
}