package datos;

public class Cliente {
//___
	private String nombre_cliente;
	private String apellido_cliente;
	private long dni_cliente;
	private long id_afiliacion_obrasocial;
	private String calle_domicilio;
//___
public Cliente(){}
public Cliente(String nombre_cliente, String apellido_cliente, long dni_cliente, long id_afiliacion_obrasocial,
		String calle_domicilio) {
	super();
	this.nombre_cliente = nombre_cliente;
	this.apellido_cliente = apellido_cliente;
	this.dni_cliente = dni_cliente;
	this.id_afiliacion_obrasocial = id_afiliacion_obrasocial;
	this.calle_domicilio = calle_domicilio;
}
//___
public String getNombre_cliente() {
	return nombre_cliente;
}
public void setNombre_cliente(String nombre_cliente) {
	this.nombre_cliente = nombre_cliente;
}
public String getApellido_cliente() {
	return apellido_cliente;
}
public void setApellido_cliente(String apellido_cliente) {
	this.apellido_cliente = apellido_cliente;
}
public long getDni_cliente() {
	return dni_cliente;
}
public void setDni_cliente(long dni_cliente) {
	this.dni_cliente = dni_cliente;
}
public long getId_afiliacion_obrasocial() {
	return id_afiliacion_obrasocial;
}
public void setId_afiliacion_obrasocial(long id_afiliacion_obrasocial) {
	this.id_afiliacion_obrasocial = id_afiliacion_obrasocial;
}
public String getCalle_domicilio() {
	return calle_domicilio;
}
public void setCalle_domicilio(String calle_domicilio) {
	this.calle_domicilio = calle_domicilio;
}
//_____________________
@Override
public String toString() {
	return "Cliente [nombre_cliente=" + nombre_cliente + ", apellido_cliente=" + apellido_cliente + ", dni_cliente="
			+ dni_cliente + ", id_afiliacion_obrasocial=" + id_afiliacion_obrasocial + ", calle_domicilio="
			+ calle_domicilio + "]";
}
//_________________________________________________________________________________________________________________
}
