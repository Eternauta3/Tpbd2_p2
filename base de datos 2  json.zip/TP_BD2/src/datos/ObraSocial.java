package datos;

public class ObraSocial {
//___
	private String nombre_obrasocial;
	private String tipo_obrasocial;// obra social o privada
	private long id_obrasocial;// id_afiliacion_obrasocial=id_obrasocial
//___
public ObraSocial(){}
public ObraSocial(String nombre_obrasocial, String tipo_obrasocial,long id_obraSocial) {
	super();
	this.nombre_obrasocial = nombre_obrasocial;
	this.tipo_obrasocial = tipo_obrasocial;
}
//___
public String getNombre_obrasocial() {
	return nombre_obrasocial;
}
protected void setNombre_obrasocial(String nombre_obrasocial) {
	this.nombre_obrasocial = nombre_obrasocial;
}
public String getTipo_obrasocial() {
	return tipo_obrasocial;
}
public void setTipo_obrasocial(String tipo_obrasocial) {
	this.tipo_obrasocial = tipo_obrasocial;
}
public long getId_obrasocial() {
	return id_obrasocial;
}
public void setId_obrasocial(long id_obrasocial) {
	this.id_obrasocial = id_obrasocial;
}
//____________________________________________________________________________
@Override
public String toString() {
	return "ObraSocial [nombre_obrasocial=" + nombre_obrasocial + ", tipo_obrasocial=" + tipo_obrasocial
			+ ", id_obrasocial=" + id_obrasocial + "]";
}
//____________________________________________________________________________
}
