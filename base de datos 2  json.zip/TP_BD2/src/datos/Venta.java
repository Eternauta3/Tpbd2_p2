package datos;

import java.time.LocalDate;

import gestor.GL;

public class Venta {
GL g=new GL();
//___
	private LocalDate fecha;
	private String forma_de_pago;
	private int cod_producto;
	private float precio_Final;
	private long cod_ticket;
	private int cantidad;
	private int cod_Sucursal;
	private long idos;
	private long dni_cliente;
//___
public Venta() {}
public Venta(long dni_cliente,LocalDate fecha, String forma_de_pago, int cod_producto, long cod_ticket,
		int cantidad, int cod_Sucursal, long idos) {
	super();
	this.dni_cliente=dni_cliente;
	this.fecha = fecha;
	this.forma_de_pago = forma_de_pago;
	this.cod_producto = cod_producto;
	this.cod_ticket = cod_ticket;
	this.cantidad = cantidad;
	this.cod_Sucursal = cod_Sucursal;
	this.idos = idos;
}

//____
public long getDni_cliente() {
	return dni_cliente;
}
public void setDni_cliente(long dni_cliente) {
	this.dni_cliente = dni_cliente;
}
public LocalDate getFecha() {
	return fecha;
}
public void setFecha(LocalDate fecha) {
	this.fecha = LocalDate.now();
}
public String getForma_de_pago() {
	return forma_de_pago;
}
public void setForma_de_pago(String forma_de_pago) {
	this.forma_de_pago = forma_de_pago;
}
public int getCod_producto() {
	return cod_producto;
}
public void setCod_producto(int cod_producto) {
	this.cod_producto = cod_producto;
}
public float getPrecio_Final() {
	return precio_Final;
}
public void setPrecio_Final(float precio_Final) {
Producto p1=new Producto();
for(Producto p2:g.getLp()){if(p2.getId_producto()==new Venta().getCod_producto()){p1=p2;}}
	this.precio_Final = p1.getPrecio_unitario()*new Venta().getCantidad();
}
public long getCod_ticket() {
	return cod_ticket;
}
public void setCod_ticket(long cod_ticket) {
	this.cod_ticket = cod_ticket;
}
public int getCantidad() {
	return cantidad;
}
public void setCantidad(int cantidad) {
	this.cantidad = cantidad;
}
public int getCod_Sucursal() {
	return cod_Sucursal;
}
public void setCod_Sucursal(int cod_Sucursal) {
	this.cod_Sucursal = cod_Sucursal;
}
public long getIdos() {
	return idos;
}
public void setIdos(long idos) {
	this.idos = idos;
}
//______________________________________________
@Override
public String toString() {
	return "Venta [fecha=" + fecha + ", forma_de_pago=" + forma_de_pago + ", cod_producto=" + cod_producto
			+ ", precio_Final=" + precio_Final + ", cod_ticket=" + cod_ticket + ", cantidad=" + cantidad
			+ ", cod_Sucursal=" + cod_Sucursal + ", idos=" + idos + ", dni_cliente=" + dni_cliente + "]";
}

//__________________________________________

}
