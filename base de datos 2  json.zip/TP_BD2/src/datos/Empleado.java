package datos;

public class Empleado {
//___
	private String nombre_empleado;
	private String apellido_empleado;
	private long dni_empleado;
	private long id_afiliacion_obrasocial_empleado;
	private String calle_domicilio_empleado;
//___
public Empleado(){}
public Empleado(String nombre_empleado, String apellido_empleado, long dni_empleado,
		long id_afiliacion_obrasocial_empleado, String calle_domicilio_empleado) {
	super();
	this.nombre_empleado = nombre_empleado;
	this.apellido_empleado = apellido_empleado;
	this.dni_empleado = dni_empleado;
	this.id_afiliacion_obrasocial_empleado = id_afiliacion_obrasocial_empleado;
	this.calle_domicilio_empleado = calle_domicilio_empleado;
}
//____________
public String getNombre_empleado() {
	return nombre_empleado;
}
public void setNombre_empleado(String nombre_empleado) {
	this.nombre_empleado = nombre_empleado;
}
public String getApellido_empleado() {
	return apellido_empleado;
}
public void setApellido_empleado(String apellido_empleado) {
	this.apellido_empleado = apellido_empleado;
}
public long getDni_empleado() {
	return dni_empleado;
}
public void setDni_empleado(long dni_empleado) {
	this.dni_empleado = dni_empleado;
}
public long getId_afiliacion_obrasocial_empleado() {
	return id_afiliacion_obrasocial_empleado;
}
public void setId_afiliacion_obrasocial_empleado(long id_afiliacion_obrasocial_empleado) {
	this.id_afiliacion_obrasocial_empleado = id_afiliacion_obrasocial_empleado;
}
public String getCalle_domicilio_empleado() {
	return calle_domicilio_empleado;
}
public void setCalle_domicilio_empleado(String calle_domicilio_empleado) {
	this.calle_domicilio_empleado = calle_domicilio_empleado;
}
//______________________________________________________________________________
@Override
public String toString() {
	return "Empleado [nombre_empleado=" + nombre_empleado + ", apellido_empleado=" + apellido_empleado
			+ ", dni_empleado=" + dni_empleado + ", id_afiliacion_obrasocial_empleado="
			+ id_afiliacion_obrasocial_empleado + ", calle_domicilio_empleado=" + calle_domicilio_empleado + "]";
}
//_________________________________________________________________________________________

}
