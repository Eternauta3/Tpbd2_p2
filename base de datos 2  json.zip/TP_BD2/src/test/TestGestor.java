package test;

import gestor.GL;
public class TestGestor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
GL gestor=new GL();;
//alta
  gestor.AgregarCliente("lorenzo","vermejo",12345678,(long)001,"vermejo 19");
  gestor.AgregarCliente("jose cornrlio","varza",12345,(long)002,"saaveder 11");
  gestor.AgregarDomicilio("saaaveder","augusto",(long)123,"qwertt");
  gestor.AgregarDomicilio("saaavedr","augusto",(long)1234,"qwertdft");
  gestor.AgregarObraSocial("wergds","obra social",1);
  gestor.AgregarObraSocial("wergds","obra social",2);
  gestor.AgregarProducto("perfumeria","perfume peri dico","qwqeadfavczz", 0, (float) 13.40);
  gestor.AgregarProducto("medicamento","perfume peri dico","qwqeadfavczz", 0, (float) 13.40);
  gestor.AgregarSucursal("qwer","rogelio audier","rgel2", 0,1);
  gestor.AgregarSucursal("qwer2","rogelio audier2","rgel222", 10,1);
  gestor.agregarVenta(12345678,"credito", 0, 0,1, 0,1);
//__________________________________________________________________________________________________

	}

}
