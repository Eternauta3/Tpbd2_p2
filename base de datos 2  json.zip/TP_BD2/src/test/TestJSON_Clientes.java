package test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.google.gson.Gson;
import datos.Cliente;
import gestor.gestorTP;
public class TestJSON_Clientes {

	public static void main(String[] args) throws IOException {
gestorTP gc=new gestorTP();
Gson gson=new Gson();


gc.AgregarCliente("Cornelio","Del Rancho", 0, 0,"vermejo");
gc.AgregarCliente("Jorge","Del Rio", 1, 0,"vermejo");
Cliente c1 =gc.TraerCliente(0);
Cliente c2 =gc.TraerCliente(1);
System.out.println(c1.toString());
System.out.println(c2.toString());


String json2=gson.toJson(c1);
String json=gson.toJson(c1);
System.out.println(json2);

try(BufferedWriter bw=new BufferedWriter(new FileWriter("datos.json"))){
try {
	bw.write(json2);
	System.out.print("fichero creado");
}catch (IOException ex) {Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE,null,ex);}

try(BufferedWriter bw2=new BufferedWriter(new FileWriter("datos2.json"))){
try {
	bw2.write(json);
	System.out.print("fichero creado");
}catch (IOException ex) {Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE,null,ex);}}
}

}}