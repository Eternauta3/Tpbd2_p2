package gestor;

import java.time.LocalDate;
import java.util.ArrayList;

import datos.Cliente;
import datos.Domicilio;
import datos.Empleado;
import datos.ObraSocial;
import datos.Producto;
import datos.Sucursal;
import datos.Venta;

public class GL {
//_____________________________________________________________
private ArrayList<Cliente> Lc;
private ArrayList<Domicilio> Ld;
private ArrayList<ObraSocial> Los;
private ArrayList<Producto> Lp;
private ArrayList<Sucursal> Ls;
private ArrayList<Venta> Lv;
private ArrayList<Empleado>Le; 
//_______________________________________________________________
public GL() {
	this.Lc = new ArrayList<Cliente>();
	this.Ld = new ArrayList<Domicilio>();
	this.Los = new ArrayList<ObraSocial>();
	this.Lp = new ArrayList<Producto>();
	this.Ls = new ArrayList<Sucursal>();
	this.Lv = new ArrayList<Venta>();
	this.Le=new ArrayList<Empleado>();
}
//______________________________________________________________________
public boolean AgregarCliente(String nombre,String apellido,int i,long idOS,String calle){
return Lc.add(new Cliente(nombre,apellido,i,idOS,calle));
}
public ArrayList<Cliente> getLc() {
	return Lc;
}
public void setLc(ArrayList<Cliente> lc) {
	Lc = lc;
}
public ArrayList<Domicilio> getLd() {
	return Ld;
}
public void setLd(ArrayList<Domicilio> ld) {
	Ld = ld;
}
public ArrayList<ObraSocial> getLos() {
	return Los;
}
public void setLos(ArrayList<ObraSocial> los) {
	Los = los;
}
public ArrayList<Producto> getLp() {
	return Lp;
}
public void setLp(ArrayList<Producto> lp) {
	Lp = lp;
}
public ArrayList<Sucursal> getLs() {
	return Ls;
}
public void setLs(ArrayList<Sucursal> ls) {
	Ls = ls;
}
public ArrayList<Venta> getLv() {
	return Lv;
}
public void setLv(ArrayList<Venta> lv) {
	Lv = lv;
}

public ArrayList<Empleado> getLe() {
	return Le;
}
public void setLe(ArrayList<Empleado> le) {
	Le = le;
}
//____________________________________________________________________
public Cliente TraerCliente(long dni_c) {
Cliente c=new Cliente();
for(Cliente c2:Lc){if(c2.getDni_cliente()==dni_c){c=c2;}}
return c;
}

public boolean EliminarCliente(long dnic) throws Exception {
Cliente c1=TraerCliente(dnic);if(TraerCliente(dnic)==null){throw new Exception("no existe cliente");}
return Lc.remove(c1);
}

public Sucursal TraerSucursal(int is_s) {
Sucursal s=new Sucursal();
for(Sucursal s2:Ls){if(s.getId_Sucursal()==is_s){s=s2;}}
return s;
}

public Empleado TraerEmpleado(long dni_e) {
Empleado c=new Empleado();
for(Empleado c2:Le){if(c2.getDni_empleado()==dni_e){c=c2;}}
return c;
}

public boolean EliminarEmpleado(long dnic) throws Exception {
Empleado c1=TraerEmpleado(dnic);if(TraerEmpleado(dnic)==null){throw new Exception("no existe cliente");}
return Le.remove(c1);
}

public boolean AgregarEmpleado(String nombre,String apellido,long dni,long os,String calle) {
return Le.add(new Empleado(nombre,apellido,dni,os,calle));
}

public boolean AgregarDomicilio(String calle,String localidad,long numero,String provincia) {
return Ld.add(new Domicilio(calle,localidad,numero,provincia));
}

public Domicilio TraerDomicilio(long numero){
Domicilio d=new Domicilio();
for(Domicilio d1:Ld){if(d1.getNumero()==numero){d=d1;}}
return d;
}

public boolean EliminarDomicilio(long numero)throws Exception{
Domicilio d2=TraerDomicilio(numero);
if(TraerDomicilio(numero)==null){throw new Exception("no existe domicilio");}
return Ld.remove(d2);
}

public boolean AgregarObraSocial(String nombre,String razon,long id) {
return Los.add(new ObraSocial(nombre,razon,id));
}

public ObraSocial TraerObraSocial(long id) {
ObraSocial os=new ObraSocial();
for(ObraSocial o2:Los) {if(o2.getId_obrasocial()==id) {os=o2;}}
return os;
}

public boolean AgregarProducto(String tipo,String descripcion,String nombre,int id,float precio){
return Lp.add(new Producto(tipo,descripcion,nombre,precio,id));
}

public ArrayList<Producto> TraerProductoPorTipo(String tipo){
ArrayList<Producto> p=new ArrayList<Producto>();
for(Producto p2:Lp){if(p2.getTipo_producto().equals(tipo)){p.add(p2);}}
return p;
}

public Producto TraerProducto(int id) {
Producto p=new Producto();
for(Producto p3:Lp){if(p3.getId_producto()==id){p=p3;}}
return p;
}

public boolean agregarVenta(long dnc,String fpago,int codp,long cod,int cant,int cs,long os) {
LocalDate fecha=LocalDate.now();
return Lv.add(new Venta(dnc,fecha,fpago,codp,cod,cant,cs,os));
}

public Venta TraerVenta(long cod){
Venta v=new Venta();
for(Venta v2:Lv){if(v2.getCod_ticket()==cod){v=v2;}}
return v;
}

public boolean AgregarSucursal(String calle,String ne,String nc,int id,long ticket){
return Ls.add(new Sucursal(calle,ne,nc,id,ticket));
}

public ArrayList<Sucursal> traerCadena(){
ArrayList<Sucursal> s=new ArrayList<Sucursal>();
for(Sucursal sw:Ls) {s.add(sw);}return s;
}

public ArrayList<Cliente> traerClientes(){
ArrayList<Cliente> s=new ArrayList<Cliente>();
for(Cliente sw:Lc) {s.add(sw);}return s;
}

//____________________________________________________________________________

}
