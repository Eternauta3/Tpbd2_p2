package dao;

import java.lang.reflect.ParameterizedType;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import datos.Aula;
import datos.Edificio;
import datos.Espacio;
import datos.Laboratorio;
import datos.Tradicional;

public class AulasDao {
//_______________________________________________________________________________________________________________________________
		private Aula clasePersistente;
		protected static Session session;
	    protected Transaction tx;
//_______________________________________________________________________________________________________________________________
	public Aula getClasePersistente() {return clasePersistente;} 
	protected void UsuarioDao(){  
	 this.clasePersistente = (Aula)((ParameterizedType)getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	} 
	protected void iniciaOperacion() throws HibernateException {
	     session = HibernateUtil.getSessionFactory().openSession();
	     tx = session.beginTransaction();
	 }
	protected void manejaExcepcion(HibernateException he) throws HibernateException {
	     tx.rollback();
	     throw new HibernateException("ERROR en la capa de acceso a datos", he);
	 }
//_______________________________________________________________________________________________________________________________
	@SuppressWarnings("unchecked")
	public List<Aula> traerAulas() throws HibernateException {List<Aula> lista=null;
	try {iniciaOperacion();lista=session.createQuery("from "+clasePersistente).list();  
	}finally {session.close();}return lista;
	}
//_______________________________________________________________________________________________________________________________
@SuppressWarnings("unchecked")
public List<Laboratorio> traerLaboratorios() throws HibernateException {List<Laboratorio> lista=null;
try {iniciaOperacion();lista=session.createQuery("from "+clasePersistente).list();  
}finally {session.close();}return lista;}
//_______________________________________________________________________________________________________________________________
@SuppressWarnings("unchecked")
public List<Tradicional> traerTradicionales() throws HibernateException {List<Tradicional> lista=null;
try {iniciaOperacion();lista=session.createQuery("from "+clasePersistente).list();  
}finally {session.close();}return lista;}
//_______________________________________________________________________________________________________________________________

public int agregarAula(Aula objeto) {
int id = 0;
try {iniciaOperacion();id = (int)session.save(objeto);tx.commit();} 
catch (HibernateException he) {manejaExcepcion(he);throw he;} 
finally {session.close();}return id;
}
//_______________________________________________________________________________________________________________________________
public int agregarEdificio(Edificio objeto) {
int id = 0;
try {iniciaOperacion();id = (int)session.save(objeto);tx.commit();} 
catch (HibernateException he) {manejaExcepcion(he);throw he;} 
finally {session.close();}return id;
}
//_______________________________________________________________________________________________________________________________
public int agregarEspacio(Espacio objeto) {
int id = 0;
try {iniciaOperacion();id = (int)session.save(objeto);tx.commit();} 
catch (HibernateException he) {manejaExcepcion(he);throw he;} 
finally {session.close();}return id;
}
//_______________________________________________________________________________________________________________________________
public int agregarLaboratorio(Laboratorio objeto) {
int id = 0;
try {iniciaOperacion();id = (int)session.save(objeto);tx.commit();} 
catch (HibernateException he) {manejaExcepcion(he);throw he;} 
finally {session.close();}return id;
}
//_______________________________________________________________________________________________________________________________
public int agregarTradicional(Tradicional objeto) {
int id = 0;
try {iniciaOperacion();id = (int)session.save(objeto);tx.commit();} 
catch (HibernateException he) {manejaExcepcion(he);throw he;} 
finally {session.close();}return id;
}
//_______________________________________________________________________________________________________________________________
//_______________________________________________________________________________________________________________________________
public Aula traerAula(int id) {
Aula objeto = null;
try {iniciaOperacion();objeto = (Aula) session.createQuery("from Aula u where u.id =" + id).uniqueResult();}
finally{session.close();}return objeto;
}
//_______________________________________________________________________________________________________________________________
public Edificio traerEdificio(long id) {
Edificio objeto = null;
try {iniciaOperacion();objeto = (Edificio) session.createQuery("from Edificio u where u.id =" + id).uniqueResult();}
finally{session.close();}return objeto;
}
//_______________________________________________________________________________________________________________________________
public Espacio traerEspacio(long id) {
Espacio objeto = null;
try {iniciaOperacion();objeto = (Espacio) session.createQuery("from Espacio u where u.id =" + id).uniqueResult();}
finally{session.close();}return objeto;
}
//_______________________________________________________________________________________________________________________________
public Laboratorio traerLaboratorio(long id) {
Laboratorio objeto = null;
try {iniciaOperacion();objeto = (Laboratorio) session.createQuery("from Laboratorio u where u.numero =" + id).uniqueResult();}
finally{session.close();}return objeto;
}
//_______________________________________________________________________________________________________________________________
public Tradicional traerTradicional(long id) {
Tradicional objeto = null;
try {iniciaOperacion();objeto = (Tradicional) session.createQuery("from Tradicional u where u.numero =" + id).uniqueResult();}
finally{session.close();}return objeto;
}
//_______________________________________________________________________________________________________________________________
}
