package negocio;

import java.util.List;

import dao.AulasDao;
import datos.Aula;
import datos.Edificio;
import datos.Laboratorio;
import datos.Tradicional;

public class AulaABM {
//__________________________________________________
private static AulaABM instancia=null;
public AulaABM() {};
//__________________________________________________
public static AulaABM getInstance(){
if(instancia==null)instancia=new AulaABM();
return instancia;
}	
AulasDao ud=null;
//__________________________________________________
public Aula traer(int dni){
return ud.traerAula(dni);
}
public List<Aula> traerAulas(){
return ud.traerAulas();
}
//__________________________________________________
public Laboratorio traerLaboratorio(int dni){
return ud.traerLaboratorio(dni);
}
public List<Laboratorio> traerLaboratorios1(){
return ud.traerLaboratorios();
}
//__________________________________________________
public Tradicional traerTradicional(int dni){
return ud.traerTradicional(dni);
}
public List<Tradicional> traerTradicionales(){
return ud.traerTradicionales();
}
//__________________________________________________
//public int AgregarAula(int numero, int ided) {
//	Edificio ed = ud.traerEdificio(ided);
//	return ud.agregarAula(new Aula(numero, ed));
//}
//__________________________________________________
public int AgregarLaboratorio(int idau,int cpc,int cs) {
Aula  ed=ud.traerAula(idau);
int numer=ed.getNumero();Edificio e=ed.getEdificio();
Laboratorio a=new Laboratorio(numer,e,cpc,cs);
return ud.agregarLaboratorio(a);
}
//__________________________________________________
public int AgregarTradicional(int idau,int cb,String pizz) {
Aula  ed=ud.traerAula(idau);
int numer=ed.getNumero();Edificio e=ed.getEdificio();
Tradicional a=new Tradicional(numer,e,cb,pizz);
return ud.agregarTradicional(a);
}
//__________________________________________________
}
