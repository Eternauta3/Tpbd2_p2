package datos;

import java.time.LocalDate;

public class Examen extends NotaPedido{
//___---___---___---___---___---___---___
	private LocalDate fecha;
//___---___---___---___---___---___---___
public Examen() {}
public Examen(int id, char turno, Aula aula, int cantestudiantes, Catedra catedra, String descripcion, LocalDate fecha) {
	super(id, turno, aula, cantestudiantes, catedra, descripcion);
	this.fecha=fecha;
}
//___---___---___---___---___---___---___
public LocalDate getFecha() {
	return fecha;
}
public void setFecha(LocalDate fecha) {
	this.fecha = fecha;
}
//___---___---___---___---___---___---___
@Override
public String toString() {
	return "Examen [fecha=" + fecha + ", toString()=" + super.toString() + "]";
}

}
