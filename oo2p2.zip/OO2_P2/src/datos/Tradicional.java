package datos;

public class Tradicional extends Aula {
//-------------------
	private int cantbancos;
	private String pizarron;
	private boolean tieneproyector;
//-------------------
public Tradicional() {}
public Tradicional(int numero, Edificio edificio,int cantbancos,String pizarron) {
	super(numero, edificio);
	this.cantbancos=cantbancos;
	this.pizarron=pizarron;
	this.tieneproyector=true;
}
//-------------------
public int getCantbancos() {
	return cantbancos;
}
public void setCantbancos(int cantbancos) {
	this.cantbancos = cantbancos;
}
public String getPizarron() {
	return pizarron;
}
public void setPizarron(String pizarron) {
	this.pizarron = pizarron;
}
public boolean isTieneproyector() {
	return tieneproyector;
}
public void setTieneproyector(boolean tieneproyector) {
	this.tieneproyector = tieneproyector;
}
//-------------------
@Override
public String toString() {
	return "Tradicional [cantbancos=" + cantbancos + ", pizarron=" + pizarron + ", tieneproyector=" + tieneproyector
			+ ", toString()=" + super.toString() + "]";
}

}
