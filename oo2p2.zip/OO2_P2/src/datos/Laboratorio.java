package datos;

public class Laboratorio extends Aula {
//-------------------
	private int cantpc;
	private int cantsillas;
//-------------------
public  Laboratorio(){}
public Laboratorio(int numero, Edificio edificio, int cantpc,int cantsillas) {
	super(numero, edificio);
	this.cantpc=cantpc;
	this.cantsillas=cantsillas;
}
//-------------------
public int getCantpc() {
	return cantpc;
}
protected void setCantpc(int cantpc) {
	this.cantpc = cantpc;
}
public int getCantsillas() {
	return cantsillas;
}
public void setCantsillas(int cantsillas) {
	this.cantsillas = cantsillas;
}
//-------------------
@Override
public String toString() {
	return "Laboratorio [cantpc=" + cantpc + ", cantsillas=" + cantsillas + ", toString()=" + super.toString() + "]";
}
//-------------------
}
