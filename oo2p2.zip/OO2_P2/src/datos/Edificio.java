package datos;

import java.util.Set;

public class Edificio {
//_____________________
	private int id;
	private String edificio;
	private Set<Aula>aulas;
//_____________________
public Edificio() {}
	public Edificio(String edificio, Set<Aula> aulas) {
		super();
		this.edificio = edificio;
		this.aulas = aulas;
	}
//_____________________	
	public int getId() {
		return id;
	}
	protected void setId(int id) {
		this.id = id;
	}
	public String getEdificio() {
		return edificio;
	}
	public void setEdificio(String edificio) {
		this.edificio = edificio;
	}
	public Set<Aula> getAulas() {
		return aulas;
	}
	public void setAulas(Set<Aula> aulas) {
		this.aulas = aulas;
	}
//_____________________	
	@Override
	public String toString() {
		return "Edificio [id=" + id + ", edificio=" + edificio + ", aulas=" + aulas.toString() + "]";
	}

}
