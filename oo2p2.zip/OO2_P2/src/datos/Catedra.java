package datos;

import java.util.Set;

public class Catedra {
//-------------------------------------
	private int id;
	private Set<Materia> materias;
	private boolean baja;

//-------------------------------------
public Catedra() {}
public Catedra(Set<Materia> materias) {
	super();
	this.materias = materias;
	this.baja=false;
}
//-------------------------------------
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public Set<Materia> getMaterias() {
	return materias;
}
public void setMaterias(Set<Materia> materias) {
	this.materias = materias;
}

public boolean isBaja() {
	return baja;
}
public void setBaja(boolean baja) {
	this.baja = baja;
}
//-------------------------------------
@Override
public String toString() {
	return "Catedra [id=" + id + ", materias=" + materias.toString() + ", baja=" + baja + "]";
}

//-------------------------------------
}
