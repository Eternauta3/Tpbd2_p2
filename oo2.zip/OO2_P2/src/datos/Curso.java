package datos;

import java.time.LocalDate;
import java.util.Set;

public class Curso {
//___---___---___---___---___---___---___
	private String codcurso;
	private Set<LocalDate>fechasreservadas; 
	private Catedra catedra;
//___---___---___---___---___---___---___
public Curso() {}
public Curso(String codcurso, Set<LocalDate> fechasreservadas, Catedra catedra) {
	super();
	this.codcurso = codcurso;
	this.fechasreservadas = fechasreservadas;
	this.catedra = catedra;
}
//___---___---___---___---___---___---___
public String getCodcurso() {
	return codcurso;
}
public void setCodcurso(String codcurso) {
	this.codcurso = codcurso;
}
public Set<LocalDate> getFechasreservadas() {
	return fechasreservadas;
}
public void setFechasreservadas(Set<LocalDate> fechasreservadas) {
	this.fechasreservadas = fechasreservadas;
}
public Catedra getCatedra() {
	return catedra;
}
public void setCatedra(Catedra catedra) {
	this.catedra = catedra;
}
//___---___---___---___---___---___---___
@Override
public String toString() {
	return "Curso [codcurso=" + codcurso + ", fechasreservadas=" + fechasreservadas.toString() + ", catedra=" + catedra.toString() + "]";
}

}
