package negocio;

import java.util.List;

import dao.UsuariosDao;
import datos.Usuario;

public class UsuarioABM {
//__________________________________________________
	private static UsuarioABM instancia=null;
	public UsuarioABM() {};
//__________________________________________________
public static UsuarioABM getInstance(){
if(instancia==null)instancia=new UsuarioABM();
return instancia;
}	
UsuariosDao ud=new UsuariosDao();
//__________________________________________________
public Usuario traer(long dni){
return ud.traer(dni);
}
public List<Usuario> traer(){
return ud.traerUsuarios();
}
public List<Usuario> traerAlumnos(){
return ud.traerUsuariosEspecificos("alumno");
}
public List<Usuario> traerProfesores(){
return ud.traerUsuariosEspecificos("profesor");
}
//__________________________________________________
public int AgregarAlumno(String nom,String ape,long dni,String tdni,String email,String contrase�a) {
String perfil="alumno";
Usuario alumno=new Usuario(nom,ape,dni,tdni,email,contrase�a,perfil);
return ud.agregar(alumno);
}
//__________________________________________________
public int AgregarAdministrador(String nom,String ape,long dni,String tdni,String email,String contrase�a) {
String perfil="administrador";
Usuario administrador=new Usuario(nom,ape,dni,tdni,email,contrase�a,perfil);
return ud.agregar(administrador);
}
//__________________________________________________
public int AgregarAuditor(String nom,String ape,long dni,String tdni,String email,String contrase�a) {
String perfil="auditor";
Usuario auditor=new Usuario(nom,ape,dni,tdni,email,contrase�a,perfil);
return ud.agregar(auditor);
}
//__________________________________________________
public int AgregarProfesor(String nom,String ape,long dni,String tdni,String email,String contrase�a) {
String perfil="profesor";
Usuario profesor=new Usuario(nom,ape,dni,tdni,email,contrase�a,perfil);
return ud.agregar(profesor);
}
//__________________________________________________
public void EliminarUsuario(long dni) {
Usuario elim=ud.traer(dni);
ud.eliminar(elim);
}
//__________________________________________________

}
